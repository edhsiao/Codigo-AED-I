#include<stdio.h>
#include<math.h>

int main()
{
    float a,b,c,raiz,x;
    scanf("%f %f %f",&a,&b,&c);

    raiz=sqrt(pow(b,2)-(4*a*c));
    if((raiz<0) || (a==0))
        printf("Impossivel calcular");
    else
    {
        printf("R1 = %.5f\n",(-b+raiz)/(2*a));
        printf("R2 = %.5f\n",(-b-raiz)/(2*a));
    }
}
