#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,r,id,i;
    int *vet;

    while (scanf("%d %d",&n,&r)!=EOF)
    {
        vet=(int*)calloc(n,sizeof(int));
        if(n==r)
            {
                for(i=0;i<n;i++)
                {
                    scanf("%d",&id);
                    vet[id-1]=id;
                }
                printf("*\n");
            }
        else{

            for(i=0;i<r;i++)
            {
                scanf("%d",&id);
                vet[id-1]=id;
            }
            for(i=0;i<n;i++)
            {
                if(vet[i]==0)
                    printf("%d ",i+1);
            }
            printf("\n");
            }
    }
}
